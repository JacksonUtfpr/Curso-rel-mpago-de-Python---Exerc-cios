"# Curso-rel-mpago-de-Python---Exerc-cios" 
